/**
 * AJEENTY orders — receives orders from ajeenty.com/menu and serves the live status to the
 * customer's tracker. Runs inside a Google Sheet. No server of your own.
 *
 * SETUP (once, about 5 minutes)
 *   1. Create a new Google Sheet (e.g. "AJEENTY orders"). Extensions → Apps Script.
 *   2. Delete what's there, paste this whole file, and put your email in NOTIFY_EMAIL below. Save.
 *   3. Pick "setup" in the function menu at the top and press Run. Approve the permissions
 *      (if Google says "unverified app": Advanced → Go to project. It is your own script).
 *   4. Deploy → New deployment → gear icon → Web app
 *        Execute as: Me      Who has access: Anyone
 *      Copy the URL ending in /exec.
 *   5. On the website, open assets/common.js and paste that URL into ORDER_URL. Deploy the site.
 *   6. Place a test order on ajeenty.com/menu and check it lands in the Sheet and your inbox.
 *
 * AFTER ANY EDIT TO THIS FILE
 *   Deploy → Manage deployments → pencil icon → Version: New version → Deploy.
 *   (Otherwise the URL keeps running the old code. The URL itself stays the same.)
 *
 * UPDATING A CUSTOMER'S TRACKER: change the Status cell of their row.
 *   Pickup orders:   Received → Preparing → Ready for pickup → Picked up
 *   Delivery orders: Received → Preparing → On the way → Delivered
 *   Any order:       Cancelled
 *   Their screen picks up the change within about 30 seconds.
 *
 * WHAT ARRIVES: item names and quantities, pickup or delivery, name, phone, address or pickup time,
 * notes, and the customer's language. No prices are sent.
 */

const NOTIFY_EMAIL = 'you@gmail.com';

const STATUSES = ['Received', 'Preparing', 'Ready for pickup', 'On the way', 'Picked up', 'Delivered', 'Cancelled'];
const HEADERS  = ['Time', 'Order ID', 'Status', 'Type', 'Name', 'Phone', 'Address', 'Pickup time', 'Items', 'Note', 'Language'];
const ID_COL = 2, STATUS_COL = 3, TYPE_COL = 4;

// A customer sends an order: items + quantities and their details. No prices.
function doPost(e) {
  let d;
  try {
    d = JSON.parse(e.postData.contents);
  } catch (err) {
    return out({ ok: false, error: 'bad request' });
  }

  // Hidden spam-trap field: people never see it, bots fill it in.
  if (d.website) return out({ ok: true, id: 'THANKS00' });

  const type = d.type === 'delivery' ? 'delivery' : 'pickup';
  const items = (Array.isArray(d.items) ? d.items : [])
    .slice(0, 100)
    .map(i => {
      const qty = Math.max(1, Math.min(99, parseInt(i && i.qty, 10) || 1));
      const name = String((i && i.name) || '').trim().slice(0, 120);
      return name ? qty + ' x ' + name : '';
    })
    .filter(Boolean);

  const name = String(d.name || '').trim(), phone = String(d.phone || '').trim(), address = String(d.address || '').trim();
  if (!name || !phone) return out({ ok: false, error: 'missing name or phone' });
  if (type === 'delivery' && !address) return out({ ok: false, error: 'missing address' });
  if (!items.length) return out({ ok: false, error: 'empty order' });

  const lock = LockService.getScriptLock();   // two orders at the same second never overwrite each other
  lock.waitLock(20000);
  let id;
  try {
    const sh = sheet();
    do { id = Utilities.getUuid().replace(/-/g, '').slice(0, 8).toUpperCase(); }
    while (sh.getRange(1, ID_COL, Math.max(1, sh.getLastRow()), 1).createTextFinder(id).matchEntireCell(true).findNext());

    const time = type === 'pickup' ? (String(d.time || '').trim() || 'ASAP') : '';
    sh.appendRow([
      new Date(), id, 'Received', type === 'delivery' ? 'Delivery' : 'Pickup',
      safe(name), asText(phone), safe(type === 'delivery' ? address : ''), asText(time),
      safe(items.join('\n')), safe(d.note), d.lang === 'ar' ? 'Arabic' : 'English',
    ]);
    SpreadsheetApp.flush();

    try {
      MailApp.sendEmail(NOTIFY_EMAIL, 'New ' + (type === 'delivery' ? 'DELIVERY' : 'PICKUP') + ' order ' + id + ' - ' + name, [
        (type === 'delivery' ? 'DELIVERY' : 'PICKUP') + ' order ' + id,
        '',
        items.join('\n'),
        '',
        'Name: ' + name,
        'Phone: ' + phone,
        type === 'delivery' ? 'Address: ' + address : 'Pickup time: ' + time,
        d.note ? 'Notes: ' + d.note : '',
        '',
        'Open the sheet to update the status: ' + SpreadsheetApp.getActiveSpreadsheet().getUrl(),
      ].join('\n'));
    } catch (err) {
      // Daily email limit reached: the order is still saved in the sheet.
    }
  } finally {
    lock.releaseLock();
  }
  return out({ ok: true, id: id });
}

// The customer's tracker asks for the status. Returns ONLY status and type, never personal data.
function doGet(e) {
  const id = String((e.parameter && e.parameter.id) || '').toUpperCase();
  if (!/^[A-Z0-9]{8}$/.test(id)) return out({ ok: false });

  const sh = sheet();
  const cell = sh.getRange(1, ID_COL, Math.max(1, sh.getLastRow()), 1)
    .createTextFinder(id).matchEntireCell(true).findNext();
  if (!cell) return out({ ok: false });

  const row = cell.getRow();
  const status = String(sh.getRange(row, STATUS_COL).getValue() || 'Received');
  const type = String(sh.getRange(row, TYPE_COL).getValue()).toLowerCase() === 'delivery' ? 'delivery' : 'pickup';
  return out({ ok: true, status: STATUSES.indexOf(status) >= 0 ? status : 'Received', type: type });
}

// Run once: headers, Status dropdown and colors, column widths
function setup() {
  const sh = sheet();
  sh.getRange(1, 1, 1, HEADERS.length).setValues([HEADERS]).setFontWeight('bold');
  sh.setFrozenRows(1);
  sh.getRange('A:A').setNumberFormat('ddd d mmm, h:mm am/pm');
  sh.getRange('I:J').setWrap(true);
  sh.setColumnWidth(9, 260);

  const statusCol = sh.getRange(2, STATUS_COL, sh.getMaxRows() - 1, 1);
  statusCol.setDataValidation(
    SpreadsheetApp.newDataValidation().requireValueInList(STATUSES, true).setAllowInvalid(false).build()
  );

  const colors = {
    'Received': '#e5e7eb', 'Preparing': '#fef3c7', 'Ready for pickup': '#dbeafe', 'On the way': '#dbeafe',
    'Picked up': '#dcfce7', 'Delivered': '#dcfce7', 'Cancelled': '#fee2e2',
  };
  sh.setConditionalFormatRules(STATUSES.map(s =>
    SpreadsheetApp.newConditionalFormatRule()
      .whenTextEqualTo(s).setBackground(colors[s]).setRanges([statusCol]).build()
  ));

  MailApp.getRemainingDailyQuota(); // asks for the email permission now, not on the first order
}

function sheet() {
  return SpreadsheetApp.getActiveSpreadsheet().getSheets()[0];
}

// Stops anyone from typing a formula (e.g. "=IMPORTXML(...)") into your sheet.
function safe(v) {
  const s = String(v == null ? '' : v).slice(0, 1000);
  return /^[=+\-@]/.test(s) ? "'" + s : s;
}

// Keeps phone numbers and times as plain text, so a leading 0 survives ("03 123 456").
function asText(v) {
  const s = String(v == null ? '' : v).slice(0, 60);
  return s ? "'" + s : '';
}

function out(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}
