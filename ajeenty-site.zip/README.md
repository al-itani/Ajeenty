# AJEENTY website — ajeenty.com

Static site for **Cloudflare Pages** (where ajeenty.com is hosted today). No build step. Everything inside `site/` gets uploaded as is.

`Ajeenty-orders-Code.gs` (next to this README, **not** uploaded with the site) is the Google Sheet script that receives online orders. See **Online ordering** below.

**Preview on your computer:** unzip, open the `site` folder, double-click `index.html`. Everything works offline except the map tiles.

```
site/
  index.html          Homepage (English + Arabic, toggle top right)
  menu/index.html     Full interactive menu  →  ajeenty.com/menu/
  404.html            Branded "page not found" (Cloudflare returns a real 404 for unknown URLs)
  og.jpg              1200×630 link-preview image for WhatsApp / Instagram / Facebook
  _headers            Content types, caching, security headers
  _redirects          Short links: /order (→ menu), /whatsapp, /map, /directions, /ar
  robots.txt, sitemap.xml, site.webmanifest, favicon + app icons
  assets/base.css     Shared look: colours, header, footer, buttons, cards, menu transition
  assets/home.css     Homepage-only layout          assets/menu.css   Menu-only layout (oven, cards, tray)
  assets/common.js    Shared: hours, open/closed badge, language, WhatsApp links, menu transition,
                      online orders (ORDER_URL), the "your order" chip
  assets/home.js      Homepage words (EN/AR), map, photos   ·   assets/vendor/  Leaflet map library
  fonts/              Archivo, Figtree, Alexandria (self-hosted, open licence)
  img/                Emblem (cut from the logo), menu illustrations
  AJEENTY_EN_FullColor.svg   Kept at the same address as before
  .nojekyll, CNAME, order/ map/ … GitHub Pages extras (harmless on Cloudflare)
```

## Deploy

**If you upload files in the Cloudflare dashboard (Direct Upload)**
1. Cloudflare dashboard → **Workers & Pages** → open the project that serves ajeenty.com.
2. **Create deployment** → drag in the **contents of the `site` folder** (not the folder itself, and not this README).
3. Click **Save and deploy**.

**If the project is connected to GitHub/GitLab**
1. Replace the repository contents with the contents of `site/`.
2. Commit and push. Cloudflare deploys automatically.

**Check after deploying (2 minutes)**
- `ajeenty.com/anything-random` shows the "didn't make it out of the oven" page.
- `ajeenty.com/menu/` opens the menu. `ajeenty.com/order` opens the menu too (handy for QR codes). `ajeenty.com/map` opens Google Maps.
- Send `https://ajeenty.com` to yourself on WhatsApp in a **new** chat: the green preview card should appear. WhatsApp caches old previews per chat; to refresh Facebook/Instagram's copy, paste the URL into the Facebook Sharing Debugger and press **Scrape Again**.
- In Google Search Console, submit `https://ajeenty.com/sitemap.xml`.

## Deploy on GitHub Pages instead

The same `site` folder works on GitHub Pages. The extra files are already included: `.nojekyll` (serve files as is), `CNAME` (ajeenty.com), and small redirect pages so `/order`, `/whatsapp`, `/wa`, `/map`, `/directions` and `/ar` still work. GitHub ignores `_headers` and `_redirects`; that only costs you the custom caching and security headers, and nothing visible changes.

1. Create a GitHub repository and upload the **contents** of `site/` to the root of the `main` branch. Make sure the hidden `.nojekyll` file goes up too (upload from a computer, not a phone).
2. Repository **Settings → Pages** → Source: **Deploy from a branch** → `main` / `(root)` → Save.
3. Same page → **Custom domain**: `ajeenty.com` → Save. Tick **Enforce HTTPS** once it becomes available (can take up to 24 hours).
4. **Before changing DNS, remove ajeenty.com from the Cloudflare Pages project** (Custom domains tab), or the two hosts will fight over it.
5. In Cloudflare DNS for ajeenty.com, replace the current records with:
   - `A` records for `@`: `185.199.108.153`, `185.199.109.153`, `185.199.110.153`, `185.199.111.153`
   - `CNAME` for `www` → `<your-github-username>.github.io`
   - Set them to **DNS only** (grey cloud) so GitHub can issue the HTTPS certificate.

All paths are relative, so the site also works at `username.github.io/repo-name/` while you test, before the domain is switched.

**Simpler alternative:** keep Cloudflare Pages and connect it to the GitHub repository (Cloudflare → your Pages project → Settings → Builds → connect Git). You get the code on GitHub and every push deploys, and `_headers` / `_redirects` keep working.

## Adding real photos (the audit's #1 visual fix)

The homepage is already wired for photos. Until you switch them on, it shows the illustrations.

1. Create a `photos` folder inside `site/` and add these files (JPG, under ~250 KB each):

| File | Shows | Size |
|---|---|---|
| `thyme.jpg` | Zaatar man'oushe | 1200×900 |
| `akawi.jpg` | Cheese akawi man'oushe | 1200×900 |
| `doublex.jpg` | Half cheese, half zaatar | 1200×900 |
| `keshek.jpg` | Keshek man'oushe | 1200×900 |
| `lahme.jpg` | Lahme baajin | 1200×900 |
| `mixed.jpg` | Mixed dozen pastries | 1200×900 |
| `oven.jpg` | The oven | 1600×1000 |
| `counter.jpg` | The counter / shopfront | 1600×1000 |

2. In `site/index.html`, change `<body data-photos="off">` to `<body data-photos="on">`.
3. Deploy. Any photo that's missing simply falls back to its illustration.

## Online ordering (orders reach you, the customer never leaves the site)

**What the customer does:** taps the peel on items → **Place order** → chooses **Pickup** (with a time) or **Delivery** (with an address), adds name, phone and notes → **Send order**. They get an **Order confirmed** ticket with live steps:
- Pickup: Order received → Preparing → Ready for pickup → Picked up
- Delivery: Order received → Preparing → On the way → Delivered

The ticket refreshes every 30 seconds. A "Your order" chip follows them on the menu and the homepage, the link `ajeenty.com/menu/?order=ID` reopens it on any phone, and the form remembers their name, phone and address for next time.

**What you receive:** a new row in your Google Sheet plus an email — item names (in English) and quantities, pickup or delivery, name, phone, address or pickup time, notes, language. **No prices are sent.** To move an order along, change its **Status** dropdown in the Sheet (the Google Sheets app on your phone works).

**Switching it on (once, about 10 minutes):**
1. Follow the steps at the top of `Ajeenty-orders-Code.gs` (new Google Sheet → Extensions → Apps Script → paste → Run `setup` → Deploy as Web app). You get a URL ending in `/exec`.
2. Open `site/assets/common.js`, find `const ORDER_URL = '';` and paste the URL between the quotes.
3. Deploy the site, place a test order, and check it lands in the Sheet and your inbox. Change its Status and watch the ticket update.

**Until you do that, nothing is lost:**

| Where the site runs | `ORDER_URL` empty | `ORDER_URL` set |
|---|---|---|
| ajeenty.com | **WhatsApp mode:** "Send on WhatsApp" opens WhatsApp with the order already written | **Live:** orders go to the Sheet |
| Your computer or any test address | **Preview mode:** nothing is sent; the ticket's steps move on their own so you can see it | **Live** |

If sending ever fails (bad connection), the customer sees a **Send on WhatsApp** button carrying the same order, and their tray is kept.

**Open questions:** there's no delivery fee or delivery area mentioned anywhere yet, and payment method isn't stated. Tell me and I'll add them to the form and ticket.

## Where the business facts live (if hours or numbers change)

| Fact | Files to edit |
|---|---|
| Opening hours (Mon–Sat 7:00–20:00, Sunday closed) | `assets/common.js` → `HOURS` (drives the live badge on both pages and the pickup times in the order form) · the written hours in `assets/home.js` (`hoursShort`, `tk3`, `monSatH`, `fHoursP`) and `menu/index.html` (`fHoursP`), EN + AR · `index.html` → visible text + `openingHoursSpecification` · `og.jpg` (image) |
| Mobile / delivery 76 77 00 26 | `assets/common.js` (`WA`), `index.html`, `menu/index.html` (`WA` + footer), `_redirects`, `og.jpg` |
| Landline 01 633 433 | `index.html`, `menu/index.html` |
| Menu items & prices | `menu/index.html` → the `MENU` list. Homepage cards (`index.html`, "Out of the oven") repeat 6 of the prices. |

The open/closed badge ("Open now · until 8 PM", "Closed · opens Monday 7 AM") is calculated live in Beirut time from `HOURS` in `assets/common.js`, on both pages.

**One look across the site.** Both pages load `assets/base.css` for the header, footer, colours, type, buttons and cards, so a change there shows up everywhere. The language choice follows the visitor between pages.

**Menu transition.** Clicking anything that leads to the menu (header link, buttons, dish cards, footer) grows a brand arch from the tap and slides a man’oushe into the oven (about half a second). The browser holds that picture until the menu is fully drawn, then flies into the oven while the menu opens out of its mouth, so it never cuts off. Chrome, Edge and Safari 18.2+ use their built-in page transition; other browsers get the same look from an overlay. The homepage quietly preloads the menu so the wait is short. It's skipped for visitors who turn off animations in their phone or computer settings, and for Ctrl/Cmd-clicks.

**Also set the same hours on your Google Business Profile.** The website tells Google your hours, but Maps shows what's in the Business Profile.

## What changed against the audit

| Audit point | Done |
|---|---|
| No real photos | Photo slots built in (see above); illustrations until then |
| Plain Arial/Helvetica, no Arabic font | Archivo (headlines), Figtree (text), Alexandria (Arabic), self-hosted |
| WhatsApp button covers the badge on phones | Floating button now appears only after you scroll past the hero buttons; badge moved and resized |
| Phone hero almost two screens tall | Illustration panel cut by ~25% on phones |
| Links ~16px tall | Every link and button in the header, contact, map and footer is at least 44px tall |
| Broken link preview (.webp served as a download) | New `og.jpg`, 1200×630, forced to `image/jpeg` in `_headers` |
| Missing hours and address for Google | Added to the structured data with both phone numbers and the menu link; the menu page has its own structured data with every item and price |
| Random URLs return the homepage | `404.html` makes Cloudflare return a real 404 |
| robots.txt / sitemap.xml returned the homepage | Real files added |

Also new: bilingual homepage (remembers the visitor's choice and follows to the menu), "Out of the oven" menu highlights, hours table that marks today, tap-to-call numbers, menu deep links (`/menu/#it-thyme`), app icons, online ordering with live tracking, a fixed oven header with a sticky category bar, and a second "+ Mashrouha" button on every man'oushe that has one (real mashrouha price kept; the row shows the extra over the man'oushe; Large spinach has none).
