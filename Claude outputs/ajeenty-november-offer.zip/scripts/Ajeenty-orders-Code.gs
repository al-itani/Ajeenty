/**
 * AJEENTY orders — receives orders from ajeenty.com/menu and serves the live status to the
 * customer's tracker. Runs inside a Google Sheet. No server of your own.
 *
 * SETUP (once, about 5 minutes)
 *   1. Create a new Google Sheet (e.g. "AJEENTY orders"). Extensions → Apps Script.
 *   2. Delete what's there, paste this whole file, and put your email in NOTIFY_EMAIL below. Save.
 *   3. Pick "setup" in the function menu at the top and press Run. Approve the permissions
 *      (if Google says "unverified app": Advanced → Go to project. It is your own script).
 *   4. Deploy → New deployment → gear icon → Web app
 *        Execute as: Me      Who has access: Anyone
 *      Copy the URL ending in /exec.
 *   5. On the website, open assets/common.js and paste that URL into ORDER_URL. Deploy the site.
 *   6. Place a test order on ajeenty.com/menu and check it lands in the Sheet and your inbox.
 *
 * AFTER ANY EDIT TO THIS FILE
 *   Deploy → Manage deployments → pencil icon → Version: New version → Deploy.
 *   (Otherwise the URL keeps running the old code. The URL itself stays the same.)
 *
 * UPDATING A CUSTOMER'S TRACKER: change the Status cell of their row.
 *   Pickup orders:   Received → Preparing → Ready for pickup → Picked up
 *   Delivery orders: Received → Preparing → On the way → Delivered
 *   Any order:       Cancelled
 *   Their screen picks up the change within about 30 seconds.
 *
 * WHAT ARRIVES: item names and quantities, pickup or delivery, name, phone, address or pickup time,
 * notes, and the customer's language. No prices are sent.
 *
 * NOVEMBER OFFER (column M, "Promo"): every DELIVERY order that reaches this sheet between 3:00 PM and
 * 6:30 PM Beirut time, Monday to Saturday in November 2026, says "15% OFF". This uses Google's clock, not the
 * customer's phone. If the website showed the customer the discount but the order arrived after 6:30 PM,
 * the cell says "NOT ELIGIBLE" with the time it arrived (2 minutes' grace for a slow connection).
 * Charge 15% less on rows that say 15% OFF. Change the dates or hours in PROMO below (and in
 * assets/common.js on the website, which must match).
 */

const NOTIFY_EMAIL = 'you@gmail.com';

const PROMO = {
  code: 'NOV-HH15', label: '15% OFF (delivery happy hour)',
  from: '2026-11-01', to: '2026-11-30',   // Beirut dates, both included
  start: 15 * 60, last: 18 * 60 + 30,     // minutes after midnight: 3:00 PM to the 6:30 PM last order
  noDays: [7],                            // 7 = Sunday (we close at 3 PM)
  graceMins: 2,                           // only for orders the website marked as discounted
};

const STATUSES = ['Received', 'Preparing', 'Ready for pickup', 'On the way', 'Picked up', 'Delivered', 'Cancelled'];
const HEADERS  = ['Time', 'Order ID', 'Status', 'Type', 'Name', 'Phone', 'Address', 'Pickup time', 'Items', 'Note', 'Language', 'Ref', 'Promo'];
const ID_COL = 2, STATUS_COL = 3, TYPE_COL = 4, REF_COL = 12, PROMO_COL = 13;

// A customer sends an order: items + quantities and their details. No prices.
function doPost(e) {
  let d;
  try {
    d = JSON.parse(e.postData.contents);
  } catch (err) {
    return out({ ok: false, error: 'bad request' });
  }

  // Hidden spam-trap field: people never see it, bots fill it in.
  if (d.website) return out({ ok: true, id: 'THANKS00' });

  const type = d.type === 'delivery' ? 'delivery' : 'pickup';
  const items = (Array.isArray(d.items) ? d.items : [])
    .slice(0, 100)
    .map(i => {
      const qty = Math.max(1, Math.min(99, parseInt(i && i.qty, 10) || 1));
      const name = String((i && i.name) || '').trim().slice(0, 120);
      return name ? qty + ' x ' + name : '';
    })
    .filter(Boolean);

  const name = String(d.name || '').trim(), phone = String(d.phone || '').trim(), address = String(d.address || '').trim();
  if (!name || !phone) return out({ ok: false, error: 'missing name or phone' });
  if (type === 'delivery' && !address) return out({ ok: false, error: 'missing address' });
  if (!items.length) return out({ ok: false, error: 'empty order' });

  const time = type === 'pickup' ? (String(d.time || '').trim() || 'ASAP') : '';
  const promo = promoCell(type, String(d.promo || '') === PROMO.code);
  // The site gives every order a reference and sends the same one again if it retries (slow or dropped
  // connection). A reference already in the sheet means this order is saved: answer with its number, no new row.
  const ref = /^[a-z0-9]{8,40}$/i.test(String(d.ref || '')) ? String(d.ref) : '';
  const lock = LockService.getScriptLock();   // two orders at the same second never overwrite each other
  lock.waitLock(20000);
  let id;
  try {
    const sh = sheet();
    if (ref) {
      if (sh.getRange(1, REF_COL).getValue() !== 'Ref') sh.getRange(1, REF_COL).setValue('Ref').setFontWeight('bold');
      if (sh.getRange(1, PROMO_COL).getValue() !== 'Promo') sh.getRange(1, PROMO_COL).setValue('Promo').setFontWeight('bold');
      const seen = sh.getRange(1, REF_COL, Math.max(1, sh.getLastRow()), 1).createTextFinder(ref).matchEntireCell(true).findNext();
      if (seen) return out({ ok: true, id: String(sh.getRange(seen.getRow(), ID_COL).getValue()), repeat: true });
    }
    do { id = Utilities.getUuid().replace(/-/g, '').slice(0, 8).toUpperCase(); }
    while (sh.getRange(1, ID_COL, Math.max(1, sh.getLastRow()), 1).createTextFinder(id).matchEntireCell(true).findNext());

    sh.appendRow([
      new Date(), id, 'Received', type === 'delivery' ? 'Delivery' : 'Pickup',
      safe(name), asText(phone), safe(type === 'delivery' ? address : ''), asText(time),
      safe(items.join('\n')), safe(d.note), d.lang === 'ar' ? 'Arabic' : 'English', ref, promo,
    ]);
    SpreadsheetApp.flush();
  } finally {
    lock.releaseLock();   // the row is saved: let the next order in while this one's email goes out
  }

  try {
    MailApp.sendEmail(NOTIFY_EMAIL, 'New ' + (type === 'delivery' ? 'DELIVERY' : 'PICKUP') + ' order ' + id + ' - ' + name, [
      (type === 'delivery' ? 'DELIVERY' : 'PICKUP') + ' order ' + id,
      '',
      items.join('\n'),
      '',
      'Name: ' + name,
      'Phone: ' + phone,
      type === 'delivery' ? 'Address: ' + address : 'Pickup time: ' + time,
      promo ? 'Promo: ' + promo : '',
      d.note ? 'Notes: ' + d.note : '',
      '',
      'Open the sheet to update the status: ' + SpreadsheetApp.getActiveSpreadsheet().getUrl(),
    ].join('\n'));
  } catch (err) {
    // Daily email limit reached: the order is still saved in the sheet.
  }
  return out({ ok: true, id: id });
}

// The customer's tracker asks for the status. Returns ONLY status and type, never personal data.
function doGet(e) {
  const id = String((e.parameter && e.parameter.id) || '').toUpperCase();
  if (!/^[A-Z0-9]{8}$/.test(id)) return out({ ok: false });

  const sh = sheet();
  const cell = sh.getRange(1, ID_COL, Math.max(1, sh.getLastRow()), 1)
    .createTextFinder(id).matchEntireCell(true).findNext();
  if (!cell) return out({ ok: false });

  const [statusCell, typeCell] = sh.getRange(cell.getRow(), STATUS_COL, 1, TYPE_COL - STATUS_COL + 1).getValues()[0];   // Status and Type are side by side: one read
  const status = String(statusCell || 'Received');
  const type = String(typeCell).toLowerCase() === 'delivery' ? 'delivery' : 'pickup';
  return out({ ok: true, status: STATUSES.indexOf(status) >= 0 ? status : 'Received', type: type });
}

// Run once: headers, Status dropdown and colors, column widths
function setup() {
  const sh = sheet();
  sh.getRange(1, 1, 1, HEADERS.length).setValues([HEADERS]).setFontWeight('bold');
  sh.setFrozenRows(1);
  sh.getRange('A:A').setNumberFormat('ddd d mmm, h:mm am/pm');
  sh.getRange('I:J').setWrap(true);
  sh.setColumnWidth(9, 260);

  const statusCol = sh.getRange(2, STATUS_COL, sh.getMaxRows() - 1, 1);
  statusCol.setDataValidation(
    SpreadsheetApp.newDataValidation().requireValueInList(STATUSES, true).setAllowInvalid(false).build()
  );

  const colors = {
    'Received': '#e5e7eb', 'Preparing': '#fef3c7', 'Ready for pickup': '#dbeafe', 'On the way': '#dbeafe',
    'Picked up': '#dcfce7', 'Delivered': '#dcfce7', 'Cancelled': '#fee2e2',
  };
  const promoCol = sh.getRange(2, PROMO_COL, sh.getMaxRows() - 1, 1);
  sh.getRange(1, PROMO_COL).setValue('Promo').setFontWeight('bold');
  sh.setColumnWidth(PROMO_COL, 210);
  sh.setConditionalFormatRules(STATUSES.map(s =>
    SpreadsheetApp.newConditionalFormatRule()
      .whenTextEqualTo(s).setBackground(colors[s]).setRanges([statusCol]).build()
  ).concat([
    SpreadsheetApp.newConditionalFormatRule().whenTextStartsWith('15%').setBackground('#dcfce7').setBold(true).setRanges([promoCol]).build(),
    SpreadsheetApp.newConditionalFormatRule().whenTextStartsWith('NOT').setBackground('#fee2e2').setRanges([promoCol]).build(),
  ]));

  MailApp.getRemainingDailyQuota(); // asks for the email permission now, not on the first order
}

// The November offer, checked with Google's clock in Beirut time (never the customer's phone).
// claimed: the website showed this customer the discount. Returns the Promo cell: '15% OFF …', 'NOT ELIGIBLE …' or ''.
function promoCell(type, claimed) {
  const now = new Date();
  const [date, hm, dow] = Utilities.formatDate(now, 'Asia/Beirut', 'yyyy-MM-dd HH:mm u').split(' ');
  const mins = Number(hm.slice(0, 2)) * 60 + Number(hm.slice(3));
  const ok = type === 'delivery' && date >= PROMO.from && date <= PROMO.to && PROMO.noDays.indexOf(Number(dow)) < 0 &&
    mins >= PROMO.start && mins < PROMO.last + (claimed ? PROMO.graceMins : 0);
  if (ok) return PROMO.label;
  return claimed ? 'NOT ELIGIBLE (arrived ' + Utilities.formatDate(now, 'Asia/Beirut', 'h:mm a') + ')' : '';
}

function sheet() {
  return SpreadsheetApp.getActiveSpreadsheet().getSheets()[0];
}

// Stops anyone from typing a formula (e.g. "=IMPORTXML(...)") into your sheet.
function safe(v) {
  const s = String(v == null ? '' : v).slice(0, 1000);
  return /^[=+\-@]/.test(s) ? "'" + s : s;
}

// Keeps phone numbers and times as plain text, so a leading 0 survives ("03 123 456").
function asText(v) {
  const s = String(v == null ? '' : v).slice(0, 60);
  return s ? "'" + s : '';
}

function out(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}
